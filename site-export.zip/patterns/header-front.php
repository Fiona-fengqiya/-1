<?php
/**
 * Title: Header Front
 * Slug: hey/header-front
 * Categories: header
 * Block Types: core/template-part/header
 */
?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">
	<!-- wp:site-logo {"width":140,"shouldSyncIcon":false,"className":"is-style-rounded"} /-->
</div>
<!-- /wp:group -->

